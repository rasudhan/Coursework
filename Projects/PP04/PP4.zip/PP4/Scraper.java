//*******************************************************************************
//* 																			*
//* 			CIS611 Spring 2017 Anand RameshKannan, Jeffrey Cheng			*		
//* 																			*	
//* 						Program Project PP4					 				*
//* 																 			*
//* 		Scraper class has the parseData which read from url and search		*
//				the information matching with regex, also toString method		*
//					and writeToFile method.										*
//*																				*	
//* 																 			*
//* 					Date Created: 04.14.2017 					 			*
//*						Saved in: Scraper.java		 	 						*
//* 																 			*
//*******************************************************************************
package PP4;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

public class Scraper{

	private String url; 
	private String fileName;
	int count = 0;
	DataSet[] datasets = new DataSet[360];

	Scraper(String url, String fileName){
		
		this.url = url;
		

	}

	// This method will parse a dataset and scrape all the relevant information pertaining to one dataset.
	// Once all the information is fetched, it will create a DataSet object and it will be added to the datasets array
	private void parseData() throws IOException {

		//String urlString = JOptionPane.showInputDialog("Please Enter URL:");
		String inputLine = "";
		String line = "";
		int i = 0;	
		//http://archive.ics.uci.edu/ml/datasets.html
		try {
			URL url = new URL("http://archive.ics.uci.edu/ml/datasets.html");
			Scanner input = new Scanner(url.openStream());
			while (input.hasNext()) {
				inputLine += input.nextLine();
			}

		} catch (MalformedURLException e) {
			JOptionPane.showMessageDialog(null, "Invalid URL");
			return;
		}

		String regex = "\\<td\\>\\<a\\shref=\"datasets\\/(.*?)\".*?\\<b\\>\\<a\\shref=\"datasets\\/.*?\"\\>(.*?)\\<\\/a\\>.*?\">(.*?)\\&nbsp.*?\"\\>(.*?)\\&nbsp.*?\"\\>(.*?)\\&nbsp.*?\"\\>(.*?)\\&nbsp.*?\"\\>(.*?)\\&nbsp.*?\"\\>(.*?)\\&nbsp.*?\"\\>(.*?)\\&nbsp";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(inputLine);

		//1:url 2:name 3:information 4:datatype 5:default task 6:Attribute Types 7: Number of Instances 8: Number of Attributes 9: year 
		
		String strInformation = "";
		String dataType;
		String defaultTask;
		String attributeType;
		int numberInstance;
		int numberAttribute;
		int year;


		while (matcher.find()) {
			
			//reduce information string to only first 15 characters
			Pattern p = Pattern.compile(".{15}");
			Matcher m = p.matcher(matcher.group(3));
			
			if(m.find()){
				strInformation = matcher.group(3).substring(0, m.end());
			}      

			//converting space to null for data type
			if (matcher.group(4).equals("")) {
				dataType = null;
			}
			else {
				dataType = matcher.group(4);
			}
			
			//converting space to null for default taks
			if (matcher.group(5).equals("")) {
				defaultTask = null;
			}
			else {
				defaultTask = matcher.group(5);
			}
			
			//converting space to null for data attribute
			if (matcher.group(6).equals("")) {
				attributeType = null;
			}
			else {
				attributeType = matcher.group(6);
			}
			
			//converting string to int for number of instances
			if (matcher.group(7).equals("")) {
				numberInstance = 0;
			}
			else {
				numberInstance = Integer.parseInt(matcher.group(7));
			}
			//converting string to int for number of attributes
			if (matcher.group(8).equals("")) {
				numberAttribute = 0;
			}
			else {
				numberAttribute = Integer.parseInt(matcher.group(8));
			}
			
			//converting string to int for year
			if (matcher.group(9).equals("")) {
				year = 0;
			}
			else {
				year = Integer.parseInt(matcher.group(9));
			}
			
			//adding new object into datasets array
			datasets[count] = new DataSet(matcher.group(2), "http://archive.ics.uci.edu/ml/datasets/" + matcher.group(1), strInformation, dataType, defaultTask, attributeType,
					numberInstance, numberAttribute, year);
			
			count++;
			
		}
	


	}

	// will read the data from datasets array (one by one) and return a String of the all DataSet object strings in multiple lines, each line has a DataSet object String
	@Override
	public String toString() {
		
		try {
			parseData();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Invalid URL");
		}
		
		String output ="";

		for (int i = 0; i < 360; i++) {
			output += datasets[i].toString() + "\n"; 
		}
		
		output += "The number of data sets :" + "\t" + count;
		return output;

	}

	// store the program out in a text file, output.txt 
	public void writeToFile() throws FileNotFoundException {

		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());

		fileName = "output" + timeStamp + ".txt";
		File file = new File(fileName);
		PrintWriter pw = new PrintWriter(file);

		for (int i = 0; i < 360; i++) {
			pw.print(datasets[i].toString() + "\n"); 
		}
		pw.print("The number of data sets :" + "\t" + count);
		pw.close();
	}

}//end Class


