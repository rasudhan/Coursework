//*******************************************************************************
//* 																			*
//* 			CIS611 Spring 2017 Anand RameshKannan, Jeffrey Cheng			*		
//* 																			*	
//* 						Program Project PP4					 				*
//* 																 			*
//* 			UserGUI class has main methods and extends from JFrame			*
//*					layout method and ActionListener method						*
//*																				*	
//* 																 			*
//* 					Date Created: 04.14.2017 					 			*
//*						Saved in: UserGUI.java		 	 						*
//* 																 			*
//*******************************************************************************
package PP4;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.*;


public class UserGUI extends JFrame {

	static Scraper scraper;

	private JPanel top;
	private JPanel bot;
	private JPanel center;
	private JLabel label1;
	private JTextField field1;
	private JButton scraperButton;
	private JButton closeButton;
	private JButton backButton;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	private JComboBox combList;
	
	private long startTime;
	private long endTime;
	private NumberFormat formatter = new DecimalFormat("#0.0000");
	
	public UserGUI (Scraper scraper) {
		this.scraper = scraper;
		initGUI();
		layoutGUI();



		scraperButton.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e){
				//get the time when click scrapeButton
				startTime = System.currentTimeMillis();

				textArea.append(scraper.toString());
				
				//get the end time when finish scraper data
				endTime = System.currentTimeMillis();
				

				try {
					scraper.writeToFile();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				//show the time took 
				label1.setText("Status: Execution time took: " + " " + formatter.format((endTime - startTime) / 1000d) + " " + "seconds");
				
				//adding 360 data sets name into combo box
				for (int i = 0; i < 360; i ++) {
					combList.addItem(scraper.datasets[i].getName());
				}
				
	

				//adding Itemlistener for user to select different data sets
				ItemListener itemListener = new ItemListener() {

					public void itemStateChanged(ItemEvent e) {
						if (e.getStateChange() == ItemEvent.SELECTED) {

							Object item = e.getItem();

							for (int i = 0; i < 360; i++) {

								if (item.equals(scraper.datasets[i].getName())) {
									textArea.setText("Name: " + scraper.datasets[i].getName() + "\n" + "InformationURL: " + scraper.datasets[i].getInformationURL() + "\n" + 
											"First 15 characters of information: " + scraper.datasets[i].getInformation() + "\n" + "DataType: " + scraper.datasets[i].getDataType() + 
											"\n" + "DefaultTask: " + scraper.datasets[i].getDefaultTask() + "\n" + "AttributeTypes: " + scraper.datasets[i].getAttributeTypes()
											+ "\n" + "NumberOfInstances: " + scraper.datasets[i].getNumberOfInstances() + "\n" + "NumberOfAttributes: " + scraper.datasets[i].getNumberOfAttributes()
											+ "\n" +  "ReleaseYear: " + scraper.datasets[i].getReleaseYear());
								}

							}
						}

					}
				};
				//add ItemListenr into combo box
				combList.addItemListener(itemListener);
				
				scraperButton.setEnabled(false);

			}
		});

		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				close();
			}
		});

		backButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				textArea.setText("");
				for (int i = 0; i < 360; i++) {
					textArea.append(scraper.datasets[i].toString() + "\n");
				}
				textArea.append("The number of data sets :" + "\t" + "360");

			}
		});


	}

	private void initGUI() {

		top = new JPanel();
		center = new JPanel();
		bot = new JPanel();

		label1 = new JLabel("Status: Datasets not Scrapped");

		scraperButton = new JButton("Scrape Datasets!");
		backButton = new JButton("Go Back");
		closeButton = new JButton("Close");


		String[] list = {"Select Datasets"};

		combList = new JComboBox(list);
		combList.setPreferredSize(new Dimension (200, 20));
		combList.setEditable(false);

		textArea = new JTextArea(50, 150);
		//textArea.setColumns(30);

		textArea.setEditable(false);
		//textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		scrollPane = new JScrollPane(textArea);
		//scrollPane.setPreferredSize(new Dimension (10, 60));
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);


	}

	private void layoutGUI() {
		setLayout( new BorderLayout());
		this.add(top, "North");
		this.add(center, "Center");
		this.add(bot, "South");

		top.setLayout(new FlowLayout());
		top.add(combList);

		center.setPreferredSize(new Dimension(600, 300));
		center.setLayout(new BorderLayout());
		center.add(scrollPane, BorderLayout.CENTER);

		center.add(label1, BorderLayout.SOUTH);



		bot.setLayout(new FlowLayout());

		bot.add(scraperButton);
		bot.add(backButton);
		bot.add(closeButton);


	}

	void close() {
		JOptionPane.showMessageDialog(null, "GoodBye");
		System.exit(0);
	}


	public static void main (String[] args)  {

		scraper = new Scraper("URL", "filename");
		UserGUI frame = new UserGUI(scraper);
		frame.setTitle("UCI Machine Learning Repository DataSet Scraper");
		frame.pack();
		frame.setLocationRelativeTo(null); // Center the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);


	} // end main 


}// end class