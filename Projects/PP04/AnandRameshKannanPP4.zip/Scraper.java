package PP04;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Scraper{
	
	private String url; 
	private String fileName;
	private String myString="";
	private int c=0;
	
	
	
	DataSet[] datasets = new DataSet[360];
	
	Scraper(String url, String fileName){
		this.url = url;
		this.fileName=fileName;
	}
	
	// This method will parse a dataset and scrape all the relevant information pertaining to one dataset.
	// Once all the information is fetched, it will create a DataSet object and it will be added to the datasets array
	private void parseData() throws IOException {

		
		String productString = "\\b(?:(?<=title=\").*?(?=\" href=))";
		  String line;
		  Pattern productPattern = Pattern.compile(productString);
		  Pattern htmlTag=Pattern.compile("((?<=<b><a href=\"datasets/[^>]{0,30}>)(.*?)(?=</a></b>))");
		  Pattern column1=Pattern.compile("(?<=<p class=\"normal\">)(.*?)(?=</p></td>)");
		  
	      Matcher productMatcher;
	      Matcher columnMatcher;
	      
	    String name="";
	  	String informationURL = "";
	  	String information="";
	  	String dataType="";
	  	String defaultTask="";
	  	String attributeTypes="";
	  	int numberOfInstances=0;
	  	int numberOfAttributes=0;
	  	int releaseYear=0;
	  	String newString="";
	      
		 //creating the URL
        URL pageURL = new URL(url);
        
        //Create the http url connection object
        HttpURLConnection urlConnection = (HttpURLConnection) pageURL.openConnection();
       
        //Reading the stream
        InputStream in = new BufferedInputStream(urlConnection.getInputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        
        Reader r = new InputStreamReader(in);
        
        int i=1;
            
        while((line=br.readLine())!=null)
        {
        	//Regex Patterns for product title and price
  		  	productMatcher=htmlTag.matcher(line);
  		  	columnMatcher=column1.matcher(line);
  		  	while(productMatcher.find()) {
    		             
	  		  	myString = myString +"Title: " + productMatcher.group()+"\n";
	  		  	name=productMatcher.group();
  		  	
  		  	}
  		  
  		  while(columnMatcher.find()) {
  			   myString+=" Data Type: " +columnMatcher.group().replaceAll("&nbsp;", "")
  					             .replaceAll("<b><a href=\"", "")
  					             .replaceAll("\">(.*?)</a></b>","")+"\n";
  			   newString=columnMatcher.group().replaceAll("&nbsp;", "")
			             .replaceAll("<b><a href=\"", "")
			             .replaceAll("\">(.*?)</a></b>","");
  			   
  			   if(i==2) {
  				 informationURL=newString;
  				  
  			   }
  			   else if(i==3) {
  				 information=newString;
  			   }
  			   else if(i==4) {
  				 dataType=newString;
  			   }
  			   else if(i==5) {
  				   defaultTask=newString;
  			   }
  			   else if(i==6) {
  				 attributeTypes=newString;
  			   }
  			   else if(i==7) {
  				   if(!newString.isEmpty()& newString.matches("[0-9]"))
  					   numberOfInstances=Integer.parseInt(newString);
  				   else
  					 numberOfInstances=0;
  			   }
  			   else if(i==8) {
  				 if(!newString.isEmpty()& newString.matches("[0-9]"))
					   numberOfAttributes=Integer.parseInt(newString);
				   else
					 numberOfAttributes=0;
  			   }
  			   else if(i==9) {
  				 if(!newString.isEmpty() & newString.matches("[0-9]"))
					   releaseYear=Integer.parseInt(newString);
				   else
					 releaseYear=0;
  			   }
  			   else if(i==10) {
  				//Store in DataSet
  				   datasets[c]=new DataSet(name, informationURL, information,
  						   dataType, defaultTask, attributeTypes,numberOfAttributes,numberOfInstances
  						   , releaseYear);
  				   i=1;
//  				  datasets[c].setInformationURL(informationURL);
//  		  		  datasets[c].setInformation(information);
//  		  		  datasets[c].setDataType(dataType);
//  		  		  datasets[c].setDefaultTask(defaultTask);
//  		  		  datasets[c].setName(name);
//  		  		  datasets[c].setAttributeTypes(attributeTypes);
//  		  		  datasets[c].setNumberOfAttributes(numberOfAttributes);
//  		  		  datasets[c].setNumberOfInstances(numberOfInstances);
//  		  		  datasets[c].setReleaseYear(releaseYear);
  		  		  c++;		
  			   }
  			 i++;
		  	
  		  
  		  }//columnMatcher
  		  
  		  
  		  
        }// end reading loop
		
	}
	
	// will read the data from datasets array (one by one) and return a String of the all DataSet object strings in multiple lines, each line has a DataSet object String
	@Override
	public String toString() {
		
		try {
			parseData();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return myString;
		
	}
	
	// store the program out in a text file, output.txt 
	public void writeToFile() {
		
		int i=0;
		//Write PRODUCT DETAILS to a text file
		try {
            File newTextFile = new File("dataset.txt");

            FileWriter fw = new FileWriter(newTextFile);
            BufferedWriter bw = new BufferedWriter(fw);
            
            
            for(i=0;i<c;i++) {
            	bw.write(datasets[i].toString()+"\n");
            }
            
            bw.close();
            
        } catch (IOException iox) {
            //do stuff with exception
            iox.printStackTrace();
        }
	
		
		
	}
	
    }//end Class
	

