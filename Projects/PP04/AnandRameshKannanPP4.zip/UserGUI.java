package PP04;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.swing.*;

public class UserGUI extends JFrame implements ActionListener{
	
	static Scraper scraper;
	 
	 private JTextArea descriptionTextArea;
	 private JPanel controlPanel;
	 private JButton scrapeButton;
	 private JComboBox theTitle;
	 
	public UserGUI() {
		JLabel statusLabel = new JLabel("Status: ", JLabel.RIGHT);
		descriptionTextArea = new JTextArea("XML or HTML String here",20,60);
		JScrollPane scrollPane = new JScrollPane(descriptionTextArea);
		
		scrapeButton = new JButton("Scrape");
		
		controlPanel = new JPanel();
		controlPanel.setLayout(new BorderLayout());
		
		setLayout(new BorderLayout());
		
		  //Create panels
	      JPanel top = new JPanel();
	      JPanel bottom = new JPanel();
	     
	      String[] title={"sample","hjagsd"};
	      theTitle= new JComboBox(title);
	      top.add(theTitle);
	      top.add(scrapeButton);
	      
	      bottom.setLayout( new BorderLayout());
	      bottom.add(new JLabel("Summary:"),"North");
	      
	      
	    //Add the panels to the frame
	      this.add(top, "North");
	      this.add(bottom, "Center");
		
		add(statusLabel);
		add(controlPanel,BorderLayout.CENTER);
		controlPanel.add(scrollPane,BorderLayout.NORTH);
		//controlPanel.add(scrapeButton,BorderLayout.CENTER);
		
		scrapeButton.addActionListener(this);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		  if (e.getSource() == scrapeButton) {
			  
			  descriptionTextArea.setText(scraper.toString());
			  scraper.writeToFile();
		  }
		
	}
	
	public static void main (String[] args)  {
		
	       scraper = new Scraper("http://archive.ics.uci.edu/ml/datasets.html", "filename");
	       UserGUI frame = new UserGUI();
		    frame.setTitle("Machine Learning Repository");
		    frame.pack();
		    frame.setLocationRelativeTo(null); // Center the frame
		    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    frame.setVisible(true);
	       
	    } // end main 
	
}// end class