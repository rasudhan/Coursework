

package ElectricBill;

// add class template
public class Customer {

	private int customerID;
	private String fName;
	private String lName;
	private int status, NoOfKWH;
	private int billMonth;
	private double billAmount;

	private static int numberOfCustomers = 0;

	// the default class constructor
	public Customer() {

	}

	// add the class overloaded constructor

	// add setter and getter methods

	// override the toString() method


}
