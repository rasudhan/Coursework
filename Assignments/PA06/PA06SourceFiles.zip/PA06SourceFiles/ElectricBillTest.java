
package ElectricBill;

public class ElectricBillTest {
	
	@SuppressWarnings("unused")
	private ElectricBill bill;
	private String fileName;
	
ElectricBillTest(String fileName){
	bill = new ElectricBill();
	this.fileName = fileName;
		
}

public static void main(String[] args) {
		// TODO Auto-generated method stub

}

}
