package PA08;

import java.sql.Statement;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.ResultSetMetaData;


public class StaffServer {

	Socket conn;
	ServerSocket serverSocket;

	private Connection connect = null;
	private Statement st = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet rs = null;
	int port;
	public static String output;
	
	ObjectInputStream serverInputStream;
	ObjectOutputStream serverOutputStream; 
	Message message;

	private final int VIEW_OP = 0;
	private final int INSERT_OP = 1;
	private	final int UPDATE_OP = 2;
	private final int DELETE_OP = 3;
	private final int CLOSE_OP = 4;
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";   
	static final String DB_URL = "jdbc:mysql://BusCISMySQL01:3306/nearfardb"; 
	static final String USER = ;
	static final String PASS = ;


	public StaffServer (int port) throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException{
		startListening(port);
		

	}

	public Boolean startListening(int listeningPort) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		try {
			serverSocket = new ServerSocket(listeningPort);
			Class.forName(JDBC_DRIVER); 
			System.out.println("Driver loaded"); 
			connect = DriverManager.getConnection(DB_URL, USER, PASS); 
			System.out.println("Database connected"); 
		}
		catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage()+"   :It couldn't listen on the port "+listeningPort + "\n");
			return false;
		}
		conn = serverSocket.accept(); 
		serverInputStream = new ObjectInputStream(conn.getInputStream());
		serverOutputStream = new ObjectOutputStream(conn.getOutputStream());
		JOptionPane.showMessageDialog(null, "Connection Request ....... Connection Accepted" + "\n");
		receivingMessage();
		return true;
	}

	private void receivingMessage() throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {

		while (true){

			message = null;	
			message = (Message)serverInputStream.readObject();


			switch (message.type) { 

			case VIEW_OP: view(message);
			break;

			case INSERT_OP: insert(message);
			break; 

			case UPDATE_OP: update(message);
			break; 

			case DELETE_OP: delete(message);
			break;


			case CLOSE_OP: close(message);
			break;
			}
		}
	}


	public void initializeDB() {

	}

	public void view(Message message) throws SQLException{
		String sql = "SELECT * FROM nearfardb.staff";
		
		st = connect.createStatement();
		rs = st.executeQuery(sql);
		ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
		int cnumber = rsmd.getColumnCount();
		/*while (rs.next()) {
			int id = rs.getInt("id");
			String lName = rs.getString("lastName");
			String fName = rs.getString("firstName");
			String mis = rs.getString("mi");
			char mi = mis.charAt(0);
			String address = rs.getString("address");
			String city = rs.getString("city");
			String state = rs.getString("state");
			String telephone = rs.getString("telephone");
			//output += id + "\t" + lName + "\t" + fName + "\t" + mi + "\t" + address + "\t" + city + "\t" + state + "\t" + telephone + "\n";
			message = new Message (id, lName, fName, mi, address, city, state, telephone, VIEW_OP);
			try {
				sendMessage(message);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}*/
		while (rs.next()) {
			for (int i = 1; i <= cnumber; i++) {
				int id = rs.getInt("id");
				String lName = rs.getString("lastName");
				String fName = rs.getString("firstName");
				String mis = rs.getString("mi");
				char mi = mis.charAt(0);
				String address = rs.getString("address");
				String city = rs.getString("city");
				String state = rs.getString("state");
				String telephone = rs.getString("telephone");
				message = new Message (id, lName, fName, mi, address, city, state, telephone, VIEW_OP);
				try {
					sendMessage(message);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
		}
	}



	public void insert(Message message) throws SQLException {
		int id = message.id;
		String lName = message.lastName;
		String fName = message.firstName;
		char mi = message.mi;
		String address = message.address;
		String city = message.city;
		String state = message.state;
		String telephone = message.telephone;
		st = connect.createStatement();
		
		String sql = "INSERT INTO nearfardb.staff VALUES(?,?,?,?,?,?,?,?)";
		preparedStatement = connect.prepareStatement(sql);
		preparedStatement.setInt(1, id);
		preparedStatement.setString(2, lName);
		preparedStatement.setString(3, fName);
		preparedStatement.setString(4, String.valueOf(mi));
		preparedStatement.setString(5, address);
		preparedStatement.setString(6, city);
		preparedStatement.setString(7, state);
		preparedStatement.setString(8, telephone);
		
		preparedStatement.execute();
		
		System.out.print("data inserted");
	}

	public void update(Message message) throws SQLException {
		st = connect.createStatement();
		rs = st.executeQuery("update * nearfardb.staff_table Where id = " + message.id + ";");
		//UPDATE `nearfardb`.`staff_table` SET `id`='' WHERE `id`='12345678';


	}
	public void delete(Message message) throws SQLException {
		st = connect.createStatement();
		int id = message.id;
		String sql = "DELETE FROM nearfardb.staff WHERE id = ?";
		preparedStatement = connect.prepareStatement(sql);
		preparedStatement.setInt(1, id);
		//DELETE FROM `nearfardb`.`staff_table` WHERE `id`='12345678';
		preparedStatement.execute();
		System.out.println("Delete success");

	}

	public void sendMessage(Message message) throws IOException {
		
        serverOutputStream.writeObject(message);

	}

	public void close(Message message) throws IOException, SQLException{
		serverInputStream.close();
		serverOutputStream.close();
		rs.close();
		((ObjectInput) st).close();
		connect.close();
		System.exit(0);

	}



	public static void main (String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException {
		int 	port 	= 3306; 
		StaffServer server = new StaffServer(port);

	}
}
