package PA08;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.net.Socket;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

@SuppressWarnings("serial")
public class StaffClient extends JPanel{

	private Socket conn;
	private ObjectOutputStream clientOutputStream;
	private ObjectInputStream clientInputStream;
	private int port;
	static String hostname;
	private Message message;

	private JLabel label1;
	private JLabel label2;
	private JLabel label3;
	private JLabel label4;
	private JLabel label5;
	private JLabel label6;
	private JLabel label7;
	private JLabel label8;
	private JLabel label9;

	private JTextField field1;
	private JTextField field2;
	private JTextField field3;
	private JTextField field4;
	private JTextField field5;
	private JTextField field6;
	private JTextField field7;
	private JTextField field8;

	private JButton button1;
	private JButton button2;
	private JButton button3;
	private JButton button4;

	private JTextArea textArea;
	private JScrollPane scrollPane;

	JPanel panel1 = new JPanel();
	JPanel panel2 = new JPanel();
	JPanel panel3 = new JPanel();

	private final int VIEW_OP = 0;
	private final int INSERT_OP = 1;
	private final int UPDATE_OP = 2;
	private final int DELETE_OP = 3;
	private final int CLOSE_OP = 4;

	String input = "";
	int id = 0;
	String lName = "";
	String fName = "";
	char mi = '\u0000';
	String address = "";
	String city = "";
	String state = "";
	String telephone = "";
	int type = 5;




	public StaffClient (String hostname, int port) throws IOException {
		initGUI();
		doTheLayout();
		connect(hostname, port);



		button1.addActionListener( new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					view_actionPerformed(e);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		button2.addActionListener( new java.awt.event.ActionListener(){
			public void actionPerformed(ActionEvent e) {
				try {
					insert_actionPerformed(e);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		button3.addActionListener( new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					update_actionPerformed(e);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		button4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					delete_actionPerformed(e);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
			}
		});

	}
	public void connect(String hostname,int port) throws IOException{
		conn = new Socket(hostname, port);
		try {
			clientOutputStream = new ObjectOutputStream(conn.getOutputStream());
			clientInputStream = new ObjectInputStream(conn.getInputStream());
		}
		catch (StreamCorruptedException e){

		}
		System.out.print("Success");
		//frame.resposeText.append("Connected \n");

	}

	public void sendMessage(int id, String firstName, String lastName, char mi, String address, String city, String state, String telephone, int type) throws IOException, ClassNotFoundException {	

		message = new Message (id, fName, lName, mi, address, city, state, telephone, type);
		clientOutputStream.writeObject(message);
		receivingMessage();

	}

	private void receivingMessage() throws IOException, ClassNotFoundException {

		message = (Message)clientInputStream.readObject();


		switch (message.type) { 

		case VIEW_OP: if (message.id != 0){

			textArea.append(message.toString());
			break;

		}  
		}

	}

	/*public void close_actionPerformed(ActionEvent e) throws IOException{
		clientOutputStream.close();
		clientInputStream.close();
		System.exit(0);

	}*/


	public void initGUI () {

		label1 = new JLabel("Staff Information");
		label2 = new JLabel("ID");
		label3 = new JLabel("Last Name");
		label4 = new JLabel("First Name");
		label5 = new JLabel("mi");
		label6 = new JLabel("Address");
		label7 = new JLabel("City");
		label8 = new JLabel("State");
		label9 = new JLabel("Telephone");

		button1 = new JButton("View");
		button2 = new JButton("Insert");
		button3 = new JButton("Update");
		button4 = new JButton("Clear");

		field1 = new JTextField(15);
		field2 = new JTextField(13);
		field3 = new JTextField(13);
		field4 = new JTextField(3);
		field5 = new JTextField(16);
		field6 = new JTextField(10);
		field7 = new JTextField(5);
		field8 = new JTextField(10);

		textArea = new JTextArea(20, 50);
		textArea.setColumns(30);
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		scrollPane = new JScrollPane(textArea);
		scrollPane.setPreferredSize(new Dimension (15, 100));
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

	}

	public void doTheLayout() {


		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(panel1);
		add(panel2);
		add(panel3);

		panel1.setPreferredSize(new Dimension(500, 200));
		panel1.setLayout(new FlowLayout(FlowLayout.LEFT));
		panel1.add(label1);
		panel1.add(Box.createRigidArea(new Dimension(500, 5)));
		panel1.add(label2);
		panel1.add(field1);
		panel1.add(Box.createRigidArea(new Dimension(500, 0)));

		panel1.add(label3);

		panel1.add(field2);

		panel1.add(label4);
		panel1.add(field3);

		panel1.add(label5);
		panel1.add(field4);

		panel1.add(label6);
		panel1.add(field5);
		panel1.add(Box.createRigidArea(new Dimension(500, 0)));
		panel1.add(label7);
		panel1.add(field6);

		panel1.add(label8);
		panel1.add(field7);
		panel1.add(Box.createRigidArea(new Dimension(500, 0)));
		panel1.add(label9);
		panel1.add(field8);


		panel2.setLayout(new FlowLayout());
		panel2.add(button1);
		panel2.add(button2);
		panel2.add(button3);
		panel2.add(button4);

		panel3.setLayout(new BorderLayout());
		panel3.add(scrollPane, BorderLayout.CENTER);


	}


	void view_actionPerformed(ActionEvent e)throws IOException, ClassNotFoundException {
		sendMessage(0, null, null, '\u0000', null, null, null, null, VIEW_OP);
		textArea.append(StaffServer.output);


	}
	void insert_actionPerformed(ActionEvent e)throws IOException, ClassNotFoundException{

		try {
			input = field1.getText();
			id = Integer.parseInt(input);
		}
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Please enter your valid id number");
			return;
		}

		lName = field2.getText();
		fName = field3.getText();
		if (field2.getText().equalsIgnoreCase("") || field3.getText().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Please enter your last name and first name");
			return;
		}

		try {
			input = field4.getText();
			mi = input.charAt(0);
		}
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Please enter a valid mi character (Ex: F)");
			return;
		}

		address = field5.getText();
		if (field5.getText().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Please enter your  address");
			return;
		}

		city = field6.getText();
		if (field6.getText().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Please enter your city of address");
			return;
		}

		state = field7.getText();
		if (field7.getText().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Please enter your state of address");
			return;
		}

		try {
			telephone = field8.getText();

			if (!telephone.matches("^[0-9]{10}$")) {
				JOptionPane.showMessageDialog(null, "Please enter a valid phone number! \n (Ex: 650-123-5555 or (650)-123-5555 or 6501235555)");	
				return;
			}
		}
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Please enter your state of address");
			return;
		}
		sendMessage(id, fName, lName, mi, address, city, state, telephone, INSERT_OP);
		System.out.println("Insert successful");


	}

	void update_actionPerformed(ActionEvent e)throws IOException, ClassNotFoundException {

	}
	void delete_actionPerformed(ActionEvent e)throws IOException, ClassNotFoundException {
		try {
			input = field1.getText();
			id = Integer.parseInt(input);
		}
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Please enter the id you want to delete");
			
		}
 		
		sendMessage(id, null, null, '\u0000', null, null, null, null, DELETE_OP);
		
		field1.setText(null);
		field2.setText(null);
		field3.setText(null);
		field4.setText(null);
		field5.setText(null);
		field6.setText(null);
		field7.setText(null);
		field8.setText(null);
		

	}


	public static void main(String[] args) throws IOException {
		int port = 3306;
		String hostname = "localhost";
		JFrame frame = new JFrame();
		frame.setTitle("Staff Table");
		Container contentPane = frame.getContentPane();
		contentPane.add( new StaffClient(hostname, port));
		BoxLayout boxLayout = new BoxLayout(contentPane, BoxLayout.Y_AXIS);
		frame.setLayout(boxLayout);
		frame.pack();
		frame.setVisible(true);

		StaffClient client = new StaffClient(hostname, port); 


	}

}
