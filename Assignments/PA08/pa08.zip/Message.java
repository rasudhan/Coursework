package PA08;

import java.io.Serializable;


public class Message implements Serializable {

	int id;
	String firstName;
	String lastName;
	char mi;
	String address;
	String city;
	String state;
	String telephone;
	int type = 5;

	public Message (){
		this(0, null, null, '\u0000', null, null, null, null, 0);

	}

	public Message(int id, String firstName, String lastName, char mi, String address, String city, String state, String telephone, int type) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mi = mi;
		this.address = address;
		this.city = city;
		this.state = state;
		this.telephone = telephone;
		this.type = type;
	}

	@Override
	public String toString() {
		return id + ",\t" + lastName + ",\t" + firstName + ",\t" + mi + ",\t" + address + ",\t" + city + ",\t" + state + ",\t" + telephone + "\n";
	}
	

}
