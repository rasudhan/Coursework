package PA05;

public class Student {
	
	private int id;
	private String name;

	// complete student object constructor
	public Student (int id, String name){
		
	}
	// compete public getter and setter methods
}
