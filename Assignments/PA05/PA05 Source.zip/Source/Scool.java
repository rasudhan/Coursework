package PA05;

public class Scool {
	
	private static Course course;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1- Instantiates the course object
		// 2- Prompt the user to input the student data, and calls addStudentGrade() to add the student to course, for three students
		// 3- Prompt the user to input the grade data, and calls aaddStudentGradeToCourse() to add the grade to course, for three grades
		// 4- Displays the course statistics by calling displayCourseStat()
	}
	
	// it uses the course object to add a new student to the course
	public static void addStudentToCourse(int id, String name){
		
	}
	
	// it uses the course object to add a new grade object to the course
	public static void addStudentGradeToCourse(int id, String assignment, Student student, double score){
			
	}
	
	// it should display the grade average and the highest student grade, student name 
	public void displayCourseStat(){
		
	}

}
