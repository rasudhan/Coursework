package PA05;

public class Grade {
	private int id;
	private String assignment;
	private Student student;
	private double score;
	
	// complete grade object constructor
	public Grade (int id, String assignment, Student student, double score){
		
	}
	
	// compete public getter and setter methods

}
